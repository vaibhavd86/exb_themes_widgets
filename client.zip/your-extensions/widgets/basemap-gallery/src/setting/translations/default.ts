export default {
  selectMapWidget: 'Select a Map widget',
  baseMapSettings: 'Basemap settings',
  groupBasemaps: 'Synchronize with the basemap gallery settings of your organization',
  customBasemaps: 'Configure custom basemaps',
  importBasemaps: 'Import',
  importTips: 'Click the "Import" button to add basemaps for the Map widget.',
  sideTitle: 'Import basemaps',
  chooseWebmaps: 'Select a group where web maps can be used as basemaps.'
}
