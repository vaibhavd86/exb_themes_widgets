declare const _default: {
    layerIsNotSupported: string;
};
export default _default;
