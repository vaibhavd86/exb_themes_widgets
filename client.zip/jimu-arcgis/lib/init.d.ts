export declare function init(): Promise<any>;
