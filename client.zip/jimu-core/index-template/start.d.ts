declare function start(): void;
