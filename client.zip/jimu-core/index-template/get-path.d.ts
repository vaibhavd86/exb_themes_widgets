/**
 * This function will be used to init mountPath when app is downloaded.
 */
declare function getPath(): string | false;
