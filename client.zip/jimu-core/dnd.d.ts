import interact from 'interactjs';
export { interact };
