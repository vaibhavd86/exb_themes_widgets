/// <reference types="react" />
import { TransitionContainerProps } from './types';
export declare function TransitionContainer(props: TransitionContainerProps): JSX.Element;
