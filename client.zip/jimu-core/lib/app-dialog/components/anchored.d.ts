import { jsx } from '@emotion/react';
import { DialogProps } from '../types';
declare function AnchoredDialog({ dialogJson, opener, toggle }: DialogProps): jsx.JSX.Element;
export default AnchoredDialog;
