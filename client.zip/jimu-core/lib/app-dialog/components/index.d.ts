import { jsx } from '@emotion/react';
import { DialogProps } from '../types';
export declare function AppDialog(props: DialogProps): jsx.JSX.Element;
export default AppDialog;
