declare const isEventModifier: (event: any) => boolean;
export default isEventModifier;
