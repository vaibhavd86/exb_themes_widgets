export default {
  _widgetLabel: 'Basemap Gallery'
}
